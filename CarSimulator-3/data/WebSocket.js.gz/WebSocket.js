var egdoor=0;
var fldoor=0;
var frdoor=0;
var brdoor=0;
var bldoor=0;
var tdoor=0;
var acstatus=0;
var lockstatus=0;

var egdoor2="Close";
var fldoor2="Close";
var frdoor2="Close";
var brdoor2="Close";
var bldoor2="Close";
var tdoor2="Close";
var acstatus2="Close";
var lockstatus2="Close";

var redata="";

var carid=0;
var oil= 0;
var egtemp=0;
var intemp=0;
var outtemp= 0;
var speed = 0;
var egrpm= 0;

var oil2= 0;
var egtemp2= 0;
var intemp2= 0;
var outtemp2= 0;
var speed2 = 0;
var egrpm2 = 0;

var socket = new WebSocket('wss://testapi.dennysora.com:8081/socket?ID='+"66693764-26ef-49d9-8faf-6a3de72077ad");

var connection = new WebSocket('ws://'+location.hostname+':81/', ['arduino']);
connection.onopen = function () {
    connection.send('Connect ' + new Date());
};
connection.onerror = function (error) {
    console.log('WebSocket Error ', error);
};
connection.onmessage = function (e) {
    console.log('Server: ', e.data);
    if(redata!=e.data){
      socket.send(e.data);
      redata=e.data
    }
};
connection.onclose = function(){
    console.log('WebSocket connection closed');
};

function sendserver(){
    carid=document.getElementById('carid').value;
    //设置连接成功后的回调函数
    socket.onopen=function () {
        console.log("socket has been opened");
	     var message = {
			type:"gauge",
			km: speed2,
			krpm: egrpm2,
			radiator: egtemp2,
			tank: oil2,
			carId: carid,
			f: egdoor2,
			lf: fldoor2,
			rf: frdoor2,
			lb: bldoor2,
			rb: brdoor2,
			b: tdoor2
        };
        message = JSON.stringify(message);
        socket.send(message);
    };
    socket.onerror = function (error) {
        console.log('WebSocket Error ', error);
    };
    socket.onmessage = function (e) {
        console.log('Server: ', e.data);
    //    socket.send(e.data);
    };
    socket.onclose = function(){
        console.log('WebSocket connection closed');
    };

    console.log("2:"+carid.toString());
    sendjson();
    connection.send("2:"+carid.toString());
}
function startfunction(){
    document.getElementById('egdoor').style.backgroundColor = '#999';
    document.getElementById('fldoor').style.backgroundColor = '#999';
    document.getElementById('frdoor').style.backgroundColor = '#999';
    document.getElementById('bldoor').style.backgroundColor = '#999';
    document.getElementById('brdoor').style.backgroundColor = '#999';
    document.getElementById('tdoor').style.backgroundColor = '#999';
    document.getElementById('acstatus').style.backgroundColor = '#999';
    document.getElementById('lockstatus').style.backgroundColor = '#999';
}
function sendVR() {
   carid=document.getElementById('carid').value;
   oil= document.getElementById('oil').value;
   egtemp= document.getElementById('egtemp').value;
   intemp= document.getElementById('intemp').value;
   outtemp= document.getElementById('outtemp').value;
if (oil!=oil2 || egtemp!=egtemp2 || intemp!=intemp2 || outtemp!=outtemp2) {
  var sendstr2 = carid.toString()+":"+oil.toString()+":"+egtemp.toString()+":"+intemp.toString()+":"+outtemp.toString();
  console.log('VR:' + sendstr2);
  connection.send("0:"+sendstr2);
  oil2=oil;
  egtemp2=egtemp;
  intemp2=intemp;
  outtemp2=outtemp;
  sendjson();
  var message = {
			type:"gauge",
			km: speed2,
			krpm: egrpm2,
			radiator: egtemp2,
			tank: oil2,
			carId: carid,
			f: egdoor2,
			lf: fldoor2,
			rf: frdoor2,
			lb: bldoor2,
			rb: brdoor2,
			b: tdoor2
        };
        message = JSON.stringify(message);
        socket.send(message);
}
}


function sendnow() {
   carid=document.getElementById('carid').value;
   speed = document.getElementById('speed').value;
   egrpm= document.getElementById('egrpm').value;
if(speed!=speed2||egrpm!=egrpm2){
    var sendstr = carid.toString()+":"+speed.toString()+":"+egrpm.toString();
    console.log('VR:' + sendstr);
    connection.send("3:"+sendstr);
    speed2=speed;
    egrpm2=egrpm;
    sendjson();
	var message = {
			type:"gauge",
			km: document.getElementById('speed').value,
			krpm: document.getElementById('egrpm').value,
			radiator: egtemp2,
			tank: oil2,
			carId: carid,
			f: egdoor2,
			lf: fldoor2,
			rf: frdoor2,
			lb: bldoor2,
			rb: brdoor2,
			b: tdoor2
        };
        message = JSON.stringify(message);
        socket.send(message);
  }
}

function buttonsendfunction(){
    carid=document.getElementById('carid').value;
    var buttonsendstr = carid.toString()+":"+egdoor.toString()+":"+fldoor.toString()+":"+frdoor.toString()+":"+bldoor.toString()+":"+brdoor.toString()+":"+tdoor.toString()+":"+acstatus.toString()+":"+lockstatus.toString();
    console.log('Button:' + buttonsendstr);
    connection.send("1:"+buttonsendstr);
    sendjson();
	var message = {
			type:"gauge",
			km: speed2,
			krpm: egrpm2,
			radiator: egtemp2,
			tank: oil2,
			carId: carid,
			f: egdoor2,
			lf: fldoor2,
			rf: frdoor2,
			lb: bldoor2,
			rb: brdoor2,
			b: tdoor2
        };
        message = JSON.stringify(message);
        socket.send(message);
}

function egdbuttonsend(){
    if(egdoor==0){
        egdoor=1;
        egdoor2="Open";
        document.getElementById('egdoor').style.backgroundColor = '#00878F';
    }else{
        egdoor=0;
        egdoor2="Close";
        document.getElementById('egdoor').style.backgroundColor = '#999';
    }
    buttonsendfunction();
}
function fldbuttonsend(){
    if(fldoor==0){
        fldoor=1;
        fldoor2="Open";
        document.getElementById('fldoor').style.backgroundColor = '#00878F';
    }else{
        fldoor=0;
        fldoor2="Close";
        document.getElementById('fldoor').style.backgroundColor = '#999';
    }
    buttonsendfunction();
}
function frdbuttonsend(){
    if(frdoor==0){
        frdoor=1;
        frdoor2="Open";
        document.getElementById('frdoor').style.backgroundColor = '#00878F';
    }else{
        frdoor=0;
        frdoor2="Close";
        document.getElementById('frdoor').style.backgroundColor = '#999';
    }
    buttonsendfunction();
}
function bldbuttonsend(){
    if(bldoor==0){
        bldoor=1;
        bldoor2="Open";
        document.getElementById('bldoor').style.backgroundColor = '#00878F';
    }else{
        bldoor=0;
        bldoor2="Close";
        document.getElementById('bldoor').style.backgroundColor = '#999';
    }
    buttonsendfunction();
}
function brdbuttonsend(){
    if(brdoor==0){
        brdoor=1;
        brdoor2="Open";
        document.getElementById('brdoor').style.backgroundColor = '#00878F';
    }else{
        brdoor=0;
        brdoor2="Close";
        document.getElementById('brdoor').style.backgroundColor = '#999';
    }
    buttonsendfunction();
}
function tdbuttonsend(){
    if(tdoor==0){
        tdoor=1;
        tdoor2="Open";
        document.getElementById('tdoor').style.backgroundColor = '#00878F';
    }else{
        tdoor=0;
        tdoor2="Close";
        document.getElementById('tdoor').style.backgroundColor = '#999';
    }
    buttonsendfunction();
}
function acbuttonsend(){
    if(acstatus==0){
        acstatus=1;
        acstatus2="Open";
        document.getElementById('acstatus').style.backgroundColor = '#00878F';
    }else{
        acstatus=0;
        acstatus2="Close";
        document.getElementById('acstatus').style.backgroundColor = '#999';
    }
    buttonsendfunction();
}
function lockbuttonsend(){
    if(lockstatus==0){
        lockstatus=1;
        lockstatus2="Open";
        document.getElementById('lockstatus').style.backgroundColor = '#00878F';
    }else{
        lockstatus=0;
        lockstatus2="Close";
        document.getElementById('lockstatus').style.backgroundColor = '#999';
    }
    buttonsendfunction();
}

function sendjson(){
    //var str_p = JSON.stringify(str);
   // console.log('json:',str);
        var message = {
  			type:"gauge",
  			km: speed2,
  			krpm: egrpm2,
  			radiator: egtemp2,
  			tank: oil2,
  			carId: carid,
  			f: egdoor2,
  			lf: fldoor2,
  			rf: frdoor2,
  			lb: bldoor2,
  			rb: brdoor2,
  			b: tdoor2
          };
       socket.send(JSON.stringify(message));
       console.log('json:',message);
}

setInterval(sendVR,500);
setInterval(sendnow,200);
// document.getElementById('b').className = 'enabled';
        //document.getElementById('r').disabled = false;
        //document.getElementById('rainbow').style.backgroundColor = '#999';
        // document.getElementById('rainbow').style.backgroundColor = '#00878F';
